package com.example.cmmccoy.lab4.dummy

import java.util.ArrayList
import java.util.HashMap

/**
 * Helper class for providing sample content for user interfaces created by
 * Android template wizards.
 *
 * TODO: Replace all uses of this class before publishing your app.
 */
object CMccDataStore {

    /**
     * An array of sample (dummy) items.
     */
    val ITEMS: MutableList<playerItem> = ArrayList()

    /**
     * A map of sample (dummy) items, by ID.
     */
    val ITEM_MAP: MutableMap<Int, playerItem> = HashMap()

    private val COUNT = 20

    init {
        // Add some sample items.
        for (i in 1..COUNT) {
            addItem(createPlayer(i))
        }
    }

    private fun addItem(item: playerItem) {
        ITEMS.add(item)
        ITEM_MAP.put(item.num, item)
    }

    private fun createPlayer(position: Int): playerItem {
        return playerItem("Player " + position, position, "cutter", false)
    }


    /**
     * A dummy item representing a piece of content.
     */
    data class playerItem(val name: String, val num: Int, val pos: String, val captain: Boolean) {
        override fun toString(): String = name
    }
}
